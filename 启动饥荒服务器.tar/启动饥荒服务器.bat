@echo off
chcp 65001 >nul
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0饥荒服务器图形界面.ps1"
if not "%ERRORLEVEL%"=="0" pause
