﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

function Find-KleiRoot {
    $paths = @(
        (Join-Path $env:USERPROFILE 'Documents\Klei\DoNotStarveTogether'),
        (Join-Path $env:USERPROFILE 'OneDrive\Documents\Klei\DoNotStarveTogether'),
        (Join-Path $env:USERPROFILE 'OneDrive - Microsoft\Documents\Klei\DoNotStarveTogether')
    )
    $found = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1
    if ($found) { return $found }
    return $paths[0]
}

function Find-ServerExe {
    $relativePaths = @(
        "steamapps\common\Don't Starve Together Dedicated Server\bin64\dontstarve_dedicated_server_nullrenderer_x64.exe",
        "steamapps\common\Don't Starve Together Dedicated Server\bin\dontstarve_dedicated_server_nullrenderer.exe"
    )
    $roots = @()
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam')) {
        try { $roots += (Get-ItemProperty -LiteralPath $key -Name SteamPath -ErrorAction Stop).SteamPath } catch {}
    }
    $roots += @('C:\Program Files (x86)\Steam','C:\Program Files\Steam','D:\steam','E:\steam')
    $libraries = @()
    foreach ($root in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
        if (-not (Test-Path $root)) { continue }
        $libraries += $root
        $vdf = Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($line in Get-Content -LiteralPath $vdf) {
                if ($line -match '"path"\s+"([^"]+)"') { $libraries += $matches[1].Replace('\\','\') }
            }
        }
    }
    foreach ($library in ($libraries | Select-Object -Unique)) {
        foreach ($relative in $relativePaths) {
            $candidate = Join-Path $library $relative
            if (Test-Path $candidate) { return $candidate }
        }
    }
    return $null
}

$KleiRoot = Find-KleiRoot
$ServerExe = Find-ServerExe
$ServerBin = if ($ServerExe) { Split-Path $ServerExe -Parent } else { $null }
$ServerRoot = if ($ServerBin) { Split-Path $ServerBin -Parent } else { $null }
$SettingsPath = Join-Path $PSScriptRoot '服务器设置.json'
if (Test-Path $SettingsPath) {
    try {
        $settings = Get-Content -LiteralPath $SettingsPath -Raw | ConvertFrom-Json
        if ($settings.KleiRoot -and (Test-Path $settings.KleiRoot)) {
            $KleiRoot = $settings.KleiRoot
        }
        if ($settings.ServerExe -and (Test-Path $settings.ServerExe)) {
            $ServerExe = $settings.ServerExe
            $ServerBin = Split-Path $ServerExe -Parent
            $ServerRoot = Split-Path $ServerBin -Parent
        }
    } catch {}
}
$TokenCache = Join-Path $PSScriptRoot '服务器令牌\cluster_token.txt'
$TemplateRoot = Join-Path $PSScriptRoot '世界'
New-Item -ItemType Directory -Path $TemplateRoot -Force | Out-Null

function Get-Clusters {
    if (-not (Test-Path $KleiRoot)) { return @() }
    @(Get-ChildItem -LiteralPath $KleiRoot -Directory | Where-Object {
        Test-Path (Join-Path $_.FullName 'cluster.ini')
    } | Select-Object -ExpandProperty Name)
}

function Get-Templates {
    @(Get-ChildItem -LiteralPath $TemplateRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object {
            (Test-Path (Join-Path $_.FullName 'Master')) -or
            (Test-Path (Join-Path $_.FullName 'Caves'))
        } | Select-Object -ExpandProperty Name)
}

function Get-ModDirectory([string]$id) {
    if (-not $ServerRoot) { return $null }
    $paths = @(
        (Join-Path $ServerRoot "mods\$id"),
        (Join-Path $ServerRoot "mods\workshop-$id"),
        (Join-Path $ServerRoot "..\..\workshop\content\322330\$id"),
        (Join-Path $ServerRoot "..\Don't Starve Together\mods\workshop-$id")
    )
    $found = $paths | Where-Object { Test-Path (Join-Path $_ 'modinfo.lua') } | Select-Object -First 1
    if ($found) { return $found }
    return $null
}

function Get-ModName([string]$id) {
    $directory = Get-ModDirectory $id
    if (-not $directory) { return $null }
    $modInfo = Read-ModInfo (Join-Path $directory 'modinfo.lua')
    $match = [regex]::Match($modInfo, '(?m)^\s*name\s*=\s*["'']([^"'']+)["'']')
    if ($match.Success) { return $match.Groups[1].Value.Trim() }
    return $null
}

function Read-ModInfo([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    return [System.Text.Encoding]::UTF8.GetString($bytes)
}

function Get-ModInfo([string]$id) {
    $directory = Get-ModDirectory $id
    if (-not $directory) { return $null }
    $path = Join-Path $directory 'modinfo.lua'
    $info = Read-ModInfo $path
    $nameMatch = [regex]::Match($info, '(?m)^\s*name\s*=\s*["'']([^"'']+)["'']')
    $clientOnlyMatch = [regex]::Match($info, '(?m)^\s*client_only_mod\s*=\s*true')
    return [pscustomobject]@{
        Name = if ($nameMatch.Success) { $nameMatch.Groups[1].Value.Trim() } else { '未命名 Mod' }
        ClientOnly = $clientOnlyMatch.Success
    }
}

function Get-EnabledModIds([string]$path) {
    $ids = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($shard in @('Master', 'Caves')) {
        $file = Join-Path $path "$shard\modoverrides.lua"
        if (-not (Test-Path $file)) { continue }
        $content = Get-Content -LiteralPath $file -Raw
        foreach ($match in [regex]::Matches($content, 'workshop-(\d+)')) {
            [void]$ids.Add($match.Groups[1].Value)
        }
    }
    return $ids
}

function Get-InstalledMods {
    if (-not $ServerRoot) { return @() }
    $roots = @(
        (Join-Path $ServerRoot 'mods'),
        (Join-Path $ServerRoot "..\..\workshop\content\322330"),
        (Join-Path $ServerRoot "..\Don't Starve Together\mods")
    )
    $mods = @{}
    foreach ($root in ($roots | Select-Object -Unique)) {
        if (-not (Test-Path $root)) { continue }
        foreach ($directory in Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue) {
            $id = $directory.Name -replace '^workshop-', ''
            if ($id -notmatch '^\d+$') { continue }
            $infoPath = Join-Path $directory.FullName 'modinfo.lua'
            if (-not (Test-Path $infoPath)) { continue }
            $info = Read-ModInfo $infoPath
            $match = [regex]::Match($info, '(?m)^\s*name\s*=\s*["'']([^"'']+)["'']')
            $name = if ($match.Success) { $match.Groups[1].Value.Trim() } else { '未命名 Mod' }
            $mods[$id] = [pscustomobject]@{
                Id = $id
                Name = $name
                Display = "$name  [$id]"
            }
        }
    }
    @($mods.Values | Sort-Object Name)
}

function Write-DefaultFiles([string]$name, [string]$templateName) {
    $path = Join-Path $KleiRoot $name
    New-Item -ItemType Directory -Path (Join-Path $path 'Master'),(Join-Path $path 'Caves') -Force | Out-Null
@'
[GAMEPLAY]
game_mode = survival
max_players = 6
pvp = false
pause_when_empty = true

[NETWORK]
lan_only_cluster = false
cluster_password =
cluster_description = My DST server
cluster_name = New DST World
offline_cluster = false
cluster_language = zh

[MISC]
console_enabled = true

[SHARD]
shard_enabled = true
bind_ip = 127.0.0.1
master_ip = 127.0.0.1
master_port = 10888
cluster_key = defaultPass
'@ | Set-Content (Join-Path $path 'cluster.ini') -Encoding UTF8
@'
[NETWORK]
server_port = 10999
[SHARD]
is_master = true
[ACCOUNT]
encode_user_path = true
'@ | Set-Content (Join-Path $path 'Master\server.ini') -Encoding UTF8
@'
[NETWORK]
server_port = 10998
[SHARD]
is_master = false
name = Caves
id = 1219214652
[ACCOUNT]
encode_user_path = true
[STEAM]
master_server_port = 27017
authentication_port = 8767
'@ | Set-Content (Join-Path $path 'Caves\server.ini') -Encoding UTF8
    foreach ($shard in @('Master','Caves')) {
        'return {}' | Set-Content (Join-Path $path "$shard\modoverrides.lua") -Encoding UTF8
        'return {}' | Set-Content (Join-Path $path "$shard\leveldataoverride.lua") -Encoding UTF8
    }
    if ($templateName) {
        $templatePath = Join-Path $TemplateRoot $templateName
        foreach ($shard in @('Master','Caves')) {
            foreach ($fileName in @('modoverrides.lua','leveldataoverride.lua')) {
                $source = Join-Path $templatePath "$shard\$fileName"
                if (Test-Path $source) {
                    Copy-Item -LiteralPath $source -Destination (Join-Path $path "$shard\$fileName") -Force
                }
            }
        }
    }
    $token = if (Test-Path $TokenCache) {
        Get-Item -LiteralPath $TokenCache
    } else {
        Get-ChildItem -LiteralPath $KleiRoot -Filter cluster_token.txt -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if ($token) {
        Copy-Item $token.FullName (Join-Path $path 'cluster_token.txt') -Force
    }
}

$form = New-Object Windows.Forms.Form
$form.Text = '饥荒联机版服务器管理器'
$form.Size = New-Object Drawing.Size(720,560)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object Drawing.Font('Microsoft YaHei UI',10)

$label = New-Object Windows.Forms.Label
$label.Text = '选择世界：'
$label.Location = New-Object Drawing.Point(20,20)
$label.AutoSize = $true
$form.Controls.Add($label)

$world = New-Object Windows.Forms.ComboBox
$world.Location = New-Object Drawing.Point(100,16)
$world.Size = New-Object Drawing.Size(220,28)
$world.DropDownStyle = 'DropDownList'
$form.Controls.Add($world)

$templateLabel = New-Object Windows.Forms.Label
$templateLabel.Text = '世界模板：'
$templateLabel.Location = New-Object Drawing.Point(350,20)
$templateLabel.AutoSize = $true
$form.Controls.Add($templateLabel)

$template = New-Object Windows.Forms.ComboBox
$template.Location = New-Object Drawing.Point(430,16)
$template.Size = New-Object Drawing.Size(240,28)
$template.DropDownStyle = 'DropDownList'
$form.Controls.Add($template)

$status = New-Object Windows.Forms.Label
$status.Location = New-Object Drawing.Point(350,50)
$status.AutoSize = $true
$form.Controls.Add($status)

$log = New-Object Windows.Forms.TextBox
$log.Location = New-Object Drawing.Point(20,275)
$log.Size = New-Object Drawing.Size(665,245)
$log.Multiline = $true
$log.ScrollBars = 'Vertical'
$log.ReadOnly = $true
$form.Controls.Add($log)
$serverState = [pscustomobject]@{ ProcessIds = @(); Name = ''; StartedAt = [datetime]::MinValue }
$serverMonitorTimer = New-Object Windows.Forms.Timer
$serverMonitorTimer.Interval = 3000

function Refresh-Worlds {
    $world.Items.Clear()
    $clusters = @(Get-Clusters)
    if ($clusters.Count -gt 0) {
        [void]$world.Items.AddRange([string[]]$clusters)
    }
    if ($world.Items.Count -gt 0) { $world.SelectedIndex = 0 }
    $status.Text = if ($ServerExe) { "已找到服务器程序" } else { "未找到专用服务器" }
}
function Refresh-Templates {
    $template.Items.Clear()
    [void]$template.Items.Add('(不使用模板)')
    $templates = @(Get-Templates)
    if ($templates.Count -gt 0) {
        [void]$template.Items.AddRange([string[]]$templates)
    }
    $template.SelectedIndex = 0
}
function Selected-Path {
    if (-not $world.SelectedItem) { throw '请先选择或创建一个世界。' }
    Join-Path $KleiRoot ([string]$world.SelectedItem)
}
function Show-Error([object]$error) {
    [Windows.Forms.MessageBox]::Show($form,$error.Exception.Message,'操作失败','OK','Error') | Out-Null
}
function Test-Cluster([string]$name) {
    $path = Join-Path $KleiRoot $name
    $issues = [System.Collections.Generic.List[string]]::new()
    foreach ($required in @('cluster.ini','cluster_token.txt','Master\server.ini','Caves\server.ini','Master\modoverrides.lua','Caves\modoverrides.lua')) {
        if (-not (Test-Path (Join-Path $path $required))) {
            [void]$issues.Add("缺少文件：$required")
        }
    }
    $tokenPath = Join-Path $path 'cluster_token.txt'
    if ((Test-Path $tokenPath) -and [string]::IsNullOrWhiteSpace((Get-Content $tokenPath -Raw))) {
        [void]$issues.Add('cluster_token.txt 为空')
    }
    foreach ($shard in @('Master','Caves')) {
        $ini = Join-Path $path "$shard\server.ini"
        if (Test-Path $ini) {
            $content = Get-Content $ini -Raw
            if ($content -notmatch '(?m)^\s*server_port\s*=\s*\d+') {
                [void]$issues.Add("$shard\server.ini 缺少 server_port")
            }
        }
    }
    return @($issues)
}
function Read-ServerProblems([string]$name) {
    $path = Join-Path $KleiRoot $name
    $problems = [System.Collections.Generic.List[string]]::new()
    foreach ($shard in @('Master','Caves')) {
        $file = Join-Path $path "$shard\server_log.txt"
        if (-not (Test-Path $file)) { continue }
        $recent = Get-Content -LiteralPath $file -Tail 120 -ErrorAction SilentlyContinue
        if ($recent -match 'Your Server Will Not Start|No auth token could be found|E_INVALID_TOKEN') {
            [void]$problems.Add("$shard：服务器令牌无效或不存在")
        }
        if ($recent -match 'LUA ERROR|stack traceback|Error loading mod|ModIndex:.*error') {
            [void]$problems.Add("$shard：Mod 或 Lua 配置错误")
        }
        if ($recent -match 'bind.*failed|couldn.t find an open port|Address already in use') {
            [void]$problems.Add("$shard：端口被占用")
        }
    }
    return @($problems | Select-Object -Unique)
}
function Get-ServerProcesses {
    $processes = @()
    foreach ($id in @($serverState.ProcessIds)) {
        $process = Get-Process -Id $id -ErrorAction SilentlyContinue
        if ($process) { $processes += $process }
    }
    if ($ServerRoot) {
        $processes += @(Get-Process -Name 'dontstarve_dedicated_server_nullrenderer*' -ErrorAction SilentlyContinue | Where-Object {
            try { $_.Path -and $_.Path.StartsWith($ServerRoot, [System.StringComparison]::OrdinalIgnoreCase) } catch { $false }
        })
    }
    @($processes | Sort-Object Id -Unique)
}
function Add-Button([string]$text,[int]$x,[int]$y,[scriptblock]$action) {
    $button = New-Object Windows.Forms.Button
    $button.Text = $text
    $button.Location = New-Object Drawing.Point($x,$y)
    $button.Size = New-Object Drawing.Size(145,38)
    $handler = {
        try {
            & $action
        } catch {
            Show-Error $_
        }
    }.GetNewClosure()
    $button.Add_Click($handler)
    $form.Controls.Add($button)
}

Add-Button '设置/读取令牌' 20 165 {
    $dialog = New-Object Windows.Forms.OpenFileDialog
    $dialog.Filter = '服务器令牌 (cluster_token.txt)|cluster_token.txt|文本文件 (*.txt)|*.txt'
    $dialog.Title = '选择 Klei 服务器令牌文件'
    if ($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
        $content = (Get-Content -LiteralPath $dialog.FileName -Raw).Trim()
        if ([string]::IsNullOrWhiteSpace($content)) { throw '选择的文件为空。' }
        New-Item -ItemType Directory -Path (Split-Path $TokenCache -Parent) -Force | Out-Null
        [System.IO.File]::WriteAllText(
            $TokenCache,
            $content,
            (New-Object System.Text.UTF8Encoding($false))
        )
        $status.Text = '服务器令牌已缓存'
        $log.AppendText("令牌已缓存到工具目录，创建新世界时会自动使用。`r`n")
    }
}
Add-Button '创建新世界' 20 65 {
    $name = [Microsoft.VisualBasic.Interaction]::InputBox('输入英文、数字、下划线或连字符组成的名称：','创建世界')
    if ($name -and $name -match '^[A-Za-z0-9_-]+$') {
        if (Test-Path (Join-Path $KleiRoot $name)) { throw '该世界已经存在。' }
        $selectedTemplate = if ($template.SelectedIndex -gt 0) { [string]$template.SelectedItem } else { $null }
        Write-DefaultFiles $name $selectedTemplate
        Refresh-Worlds
        $world.SelectedItem = $name
        $message = if ($selectedTemplate) {
            '世界配置创建成功，已应用模板：' + $selectedTemplate + '。首次启动会生成新的地图。'
        } else {
            '世界配置创建成功。首次启动会自动生成地图。'
        }
        [Windows.Forms.MessageBox]::Show($message,'完成') | Out-Null
    } elseif ($name) { throw '名称格式不正确。' }
}
Add-Button '选择 Mod' 180 65 {
    $path = Selected-Path
    $mods = @(Get-InstalledMods)
    if ($mods.Count -eq 0) { throw '没有找到已下载的 Mod，请先在 Steam 创意工坊订阅并下载。' }
    $enabledIds = Get-EnabledModIds $path

    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = '选择要添加的 Mod'
    $dialog.Size = New-Object Drawing.Size(560,500)
    $dialog.StartPosition = 'CenterParent'
    $dialog.Font = $form.Font
    $list = New-Object Windows.Forms.CheckedListBox
    $list.Location = New-Object Drawing.Point(15,15)
    $list.Size = New-Object Drawing.Size(510,350)
    $list.CheckOnClick = $true
    $list.DisplayMember = 'Display'
    foreach ($mod in $mods) {
        $index = $list.Items.Add($mod)
        if ($enabledIds.Contains($mod.Id)) {
            $list.SetItemChecked($index, $true)
        }
    }
    $dialog.Controls.Add($list)
    $hint = New-Object Windows.Forms.Label
    $hint.Text = '服务器 Mod 将自动添加到地上世界和洞穴。'
    $hint.Location = New-Object Drawing.Point(15,380)
    $hint.AutoSize = $true
    $dialog.Controls.Add($hint)
    $ok = New-Object Windows.Forms.Button
    $ok.Text = '添加选中 Mod'
    $ok.Location = New-Object Drawing.Point(350,375)
    $ok.Size = New-Object Drawing.Size(175,35)
    $ok.DialogResult = [Windows.Forms.DialogResult]::OK
    $dialog.Controls.Add($ok)
    $dialog.AcceptButton = $ok
    if ($dialog.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK) { return }

    $selected = @($list.CheckedItems)
    if ($selected.Count -eq 0) { throw '请至少勾选一个 Mod。' }
    foreach ($mod in $selected) {
        $modInfo = Get-ModInfo $mod.Id
        if ($modInfo -and $modInfo.ClientOnly) {
            $log.AppendText("已跳过：$($mod.Name)（纯本地 Mod，不能作为服务器 Mod）。`r`n")
            continue
        }
        foreach ($shard in @('Master', 'Caves')) {
            $file = Join-Path $path "$shard\modoverrides.lua"
            $content = Get-Content -LiteralPath $file -Raw
            if ($content -match [regex]::Escape("workshop-$($mod.Id)")) {
                $log.AppendText("已跳过：$($mod.Name)（已存在于 $shard）。`r`n")
                continue
            }
            $entry = "    [`"workshop-$($mod.Id)`"] = { enabled = true },"
            $trimmed = $content.Trim()
            if ($trimmed -match '^return\s*\{\s*\}$') {
                $content = "return {`r`n$entry`r`n}"
            } elseif ($trimmed -match '^return\s*\{') {
                $content = $trimmed -replace '\}\s*$', "$entry`r`n}"
            } else {
                throw "$file 不是有效的 modoverrides.lua 格式。"
            }
            Set-Content -LiteralPath $file -Value $content -Encoding UTF8
            $log.AppendText("已添加：$($mod.Name)（$($mod.Id)）到 $shard。`r`n")
        }
    }
}
Add-Button '编辑配置' 340 65 {
    $path = Selected-Path
    Start-Process notepad.exe (Join-Path $path 'cluster.ini')
}
Add-Button '打开存档目录' 500 65 { Start-Process explorer.exe $KleiRoot }
Add-Button '验证世界' 340 165 {
    $name = [string]$world.SelectedItem
    $issues = @(Test-Cluster $name)
    if ($issues.Count -eq 0) {
        $status.Text = '验证通过'
        $log.AppendText("$name 配置验证通过。`r`n")
        [Windows.Forms.MessageBox]::Show($form,'配置文件、令牌和分片文件检查通过。','验证通过','OK','Information') | Out-Null
    } else {
        $status.Text = '验证发现问题'
        $log.AppendText("$name 验证问题：`r`n$($issues -join "`r`n")`r`n")
        [Windows.Forms.MessageBox]::Show($form,($issues -join "`r`n"),'世界配置有问题','OK','Warning') | Out-Null
    }
}
Add-Button '启动服务器' 20 120 {
    if (-not $ServerExe) { throw '没有找到 DST 专用服务器，请在 Steam 安装它。' }
    $name = [string]$world.SelectedItem
    $issues = @(Test-Cluster $name)
    if ($issues.Count -gt 0) {
        $log.AppendText("启动前检查失败：`r`n$($issues -join "`r`n")`r`n")
        [Windows.Forms.MessageBox]::Show($form,($issues -join "`r`n"),'无法启动服务器','OK','Error') | Out-Null
        return
    }
    $env:SteamAppId = '322330'
    $env:SteamGameId = '322330'
    $args = @('-console','-persistent_storage_root','APP:Klei/','-conf_dir','DoNotStarveTogether','-cluster',$name,'-shard','Master')
    $master = Start-Process $ServerExe -ArgumentList $args -WorkingDirectory $ServerBin -PassThru
    Start-Sleep 2
    $args[-1] = 'Caves'
    $caves = Start-Process $ServerExe -ArgumentList $args -WorkingDirectory $ServerBin -PassThru
    $serverState.ProcessIds = @($master.Id, $caves.Id)
    $serverState.Name = $name
    $serverState.StartedAt = [datetime]::Now
    $serverMonitorTimer.Tag = $name
    $serverMonitorTimer.Start()
    $status.Text = '正在验证服务器启动'
    $log.AppendText("$name 已启动，正在检查日志...`r`n")
}
Add-Button '停止服务器' 180 120 {
    $serverMonitorTimer.Stop()
    $processes = @(Get-ServerProcesses)
    if ($processes.Count -eq 0) {
        $status.Text = '没有发现运行中的服务器'
        $log.AppendText('没有发现可停止的服务器进程。`r`n')
        return
    }
    $stopped = 0
    foreach ($process in $processes) {
        try {
            Stop-Process -Id $process.Id -Force -ErrorAction Stop
            $stopped++
        } catch {
            $log.AppendText("停止进程 $($process.Id) 失败：$($_.Exception.Message)`r`n")
        }
    }
    Start-Sleep -Milliseconds 500
    $remaining = @(Get-ServerProcesses)
    $serverState.ProcessIds = @()
    if ($remaining.Count -eq 0) {
        $status.Text = '服务器已停止'
        $log.AppendText("已停止 $stopped 个服务器进程。`r`n")
    } else {
        $status.Text = '服务器未完全停止'
        $log.AppendText("仍有 $($remaining.Count) 个服务器进程未停止。`r`n")
    }
}
Add-Button '查看日志' 340 120 {
    $path = Selected-Path
    foreach ($file in @('Master\server_log.txt','Caves\server_log.txt')) {
        $filePath = Join-Path $path $file
        if (Test-Path $filePath) {
            $log.AppendText("===== $file =====`r`n")
            $log.AppendText((Get-Content $filePath -Tail 30 -Raw))
            $log.AppendText("`r`n")
        }
    }
}
Add-Button '编辑模组/地形' 500 120 {
    $path = Selected-Path
    Start-Process explorer.exe (Join-Path $path 'Master')
}
Add-Button '打开模板目录' 500 165 {
    Start-Process explorer.exe $TemplateRoot
}
Add-Button '手动设置路径' 20 210 {
    $folderDialog = New-Object Windows.Forms.FolderBrowserDialog
    $folderDialog.Description = '选择 Klei 存档目录（应包含世界文件夹）'
    $folderDialog.SelectedPath = $KleiRoot
    if ($folderDialog.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK) { return }
    $newKleiRoot = $folderDialog.SelectedPath
    if (-not (Test-Path (Join-Path $newKleiRoot '001')) -and
        -not (Get-ChildItem -LiteralPath $newKleiRoot -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path (Join-Path $_.FullName 'cluster.ini') } | Select-Object -First 1)) {
        throw '所选目录不是有效的 Klei 存档目录。'
    }

    $exeDialog = New-Object Windows.Forms.OpenFileDialog
    $exeDialog.Title = '选择 DST 专用服务器程序'
    $exeDialog.Filter = 'DST 服务器程序|dontstarve_dedicated_server_nullrenderer*.exe|可执行文件|*.exe'
    if ($ServerExe) { $exeDialog.FileName = $ServerExe }
    if ($exeDialog.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK) { return }
    $newServerExe = $exeDialog.FileName
    if ((Split-Path $newServerExe -Leaf) -notmatch '^dontstarve_dedicated_server_nullrenderer.*\.exe$') {
        throw '所选文件不是 DST 专用服务器程序。'
    }

    $script:KleiRoot = $newKleiRoot
    $script:ServerExe = $newServerExe
    $script:ServerBin = Split-Path $script:ServerExe -Parent
    $script:ServerRoot = Split-Path $script:ServerBin -Parent
    [pscustomobject]@{
        KleiRoot = $script:KleiRoot
        ServerExe = $script:ServerExe
    } | ConvertTo-Json | Set-Content -LiteralPath $SettingsPath -Encoding UTF8
    Refresh-Worlds
    $status.Text = '手动路径已保存'
    $log.AppendText("已保存 Klei 存档目录和服务器程序路径。`r`n")
}
Add-Button '删除当前世界' 180 165 {
    $name = [string]$world.SelectedItem
    $path = Selected-Path
    $confirmation = [Microsoft.VisualBasic.Interaction]::InputBox(
        "此操作将永久删除世界配置和存档：$name`r`n请输入世界名称以确认：",
        '确认删除世界'
    )
    if ($confirmation -ne $name) {
        if ($confirmation) { throw '确认名称不匹配，未删除世界。' }
        return
    }
    $answer = [Windows.Forms.MessageBox]::Show(
        $form,
        '确定永久删除“' + $name + '”及其全部存档吗？此操作无法撤销。',
        '最终确认',
        'YesNo',
        'Warning'
    )
    if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
    $running = @(Get-ServerProcesses)
    if ($running.Count -gt 0) {
        throw '检测到服务器仍在运行，请先停止服务器。'
    }
    Remove-Item -LiteralPath $path -Recurse -Force
    Refresh-Worlds
    $status.Text = '世界已删除'
    $log.AppendText("已删除世界：$name。`r`n")
}

$serverMonitorTimer.Add_Tick({
    $name = [string]$serverMonitorTimer.Tag
    $problems = @(Read-ServerProblems $name)
    $running = @($serverState.ProcessIds | ForEach-Object {
        Get-Process -Id $_ -ErrorAction SilentlyContinue
    })
    if ($problems.Count -gt 0) {
        $serverMonitorTimer.Stop()
        $status.Text = '服务器启动失败'
        $log.AppendText("启动检查发现问题：`r`n$($problems -join "`r`n")`r`n")
        [Windows.Forms.MessageBox]::Show($form,($problems -join "`r`n"),'服务器启动失败','OK','Error') | Out-Null
    } elseif ($running.Count -eq 2 -and ([datetime]::Now - $serverState.StartedAt).TotalSeconds -ge 10) {
        $status.Text = '服务器运行中'
        $serverMonitorTimer.Stop()
        $log.AppendText("$name 的 Master 和 Caves 进程均在运行。`r`n")
    } elseif ($running.Count -eq 0) {
        $serverMonitorTimer.Stop()
        $status.Text = '服务器已退出'
        $log.AppendText('服务器进程已退出，请点击“查看日志”获取详细原因。`r`n')
        [Windows.Forms.MessageBox]::Show($form,'服务器进程已退出，请点击“查看日志”查看错误。','服务器已退出','OK','Warning') | Out-Null
    }
}.GetNewClosure())

Refresh-Worlds
Refresh-Templates
[void]$form.ShowDialog()
